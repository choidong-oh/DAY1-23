﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day14_1
{
    internal class Item
    {

        public string ItemName;
        public string ItemType;
        public int ItemPrice;





    }
}
